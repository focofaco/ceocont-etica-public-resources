# GitHub Workflows Template Pack

**13 Production-Ready Autonomous Agents + Infrastructure**

## 📦 Contents

### Autonomous Agents (10)

**Repository Maintenance (4)**
- `commit-validator-agent.yml` - Enforces conventional commits
- `auto-label-agent.yml` - Auto-labels issues by keywords
- `pr-size-labeler-agent.yml` - Labels PRs by size (XS/S/M/L/XL)
- `branch-cleanup-agent.yml` - Cleans up merged branches

**Quality & Changelog (2)**
- `changelog-formatter-agent.yml` - Validates Keep a Changelog format
- `changelog-auto.yml` - Generates changelog from commits

**Dependency Management (4) - Python**
- `unused-deps-agent.yml` - Detects unused Python dependencies
- `outdated-deps-agent.yml` - Reports outdated packages + security
- `dep-graph-agent.yml` - Generates dependency graphs
- `breaking-change-agent.yml` - Detects breaking changes in deps

### CI/CD Infrastructure (3)
- `pre-commit-ci.yml` - Automated pre-commit hooks
- `dependency-review.yml` - Security scanning for dependencies
- `codeql.yml` - Code security analysis

### Configuration Files (7)
- `CODEOWNERS` - Auto review assignments
- `SECURITY.md` - Vulnerability reporting policy
- `dependabot.yml` - Automated dependency updates
- `pull_request_template.md` - PR checklist template
- `ISSUE_TEMPLATE/bug_report.md` - Bug report template
- `ISSUE_TEMPLATE/feature_request.md` - Feature request template
- `ISSUE_TEMPLATE/custom.md` - Custom issue template

## 🚀 Quick Start

1. **Extract** this archive to your repository root
2. **Search** for `⚠️ PLACEHOLDER` comments (4 files need customization)
3. **Replace** placeholders with your values
4. **Commit** and push to GitHub

## 📝 Required Customizations

### 1. `.github/CODEOWNERS`
```bash
# Replace in 9 locations:
@YOUR_GITHUB_USERNAME → @your-actual-username
```

### 2. `.github/dependabot.yml`
```yaml
# Line 14 and 36:
timezone: "America/Sao_Paulo" → Your timezone

# Lines 8-31: Comment out if NOT Python repo
```

### 3. `.github/pull_request_template.md`
- Customize validation checklist for your project
- Adjust documentation requirements

### 4. `.github/ISSUE_TEMPLATE/*.md`
- Add default `labels:` (optional)
- Add default `assignees:` (optional)

## ✅ Zero-Config Workflows

These 13 workflows require **NO modification**:
- All use dynamic GitHub context (`${{ github.repository }}`)
- Work with any repository structure
- Use built-in `GITHUB_TOKEN` (no secrets needed)

## 🎯 Features

**Automated Quality**
- ✅ Commit message validation
- ✅ PR size tracking
- ✅ Issue auto-labeling
- ✅ Branch cleanup
- ✅ Changelog validation

**Dependency Management**
- ✅ Unused dependency detection
- ✅ Outdated package reports
- ✅ Security vulnerability scanning
- ✅ Breaking change alerts
- ✅ Dependency graphs

**Security**
- ✅ CodeQL scanning
- ✅ Dependency review
- ✅ Vulnerability reporting process

## 📋 Prerequisites

- GitHub repository with Actions enabled
- Python repository (for 4 dependency agents)
- Conventional Commits (optional, but recommended)
- Keep a Changelog format (optional, for changelog agents)

## 🔧 Advanced Configuration

All agents support:
- **Manual triggers** via `workflow_dispatch`
- **Scheduled runs** via cron
- **Custom labels** and outputs
- **Issue creation** for reports

See individual workflow files for detailed configuration options.

## 📚 Documentation

Each workflow contains:
- Inline comments explaining logic
- Configuration examples
- Trigger conditions
- Permission requirements

## 🤝 Contributing

Found issues or want to improve? Check individual workflow files for:
- `# TODO:` comments for known limitations
- Permission scopes that can be tightened
- Schedule optimizations

## 📄 License

These workflows are production templates. Customize and use freely.

---

**Generated from**: ceocont-etica-public-resources
**Architecture**: Autonomous GitHub Actions agents
**Version**: 2.3.0 template pack
