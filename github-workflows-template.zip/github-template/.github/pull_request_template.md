## Summary

<!-- Briefly describe what this PR does and why -->

## Type of Change

- [ ] **feat**: New feature (MINOR version bump)
- [ ] **fix**: Bug fix (PATCH version bump)
- [ ] **docs**: Documentation updates
- [ ] **refactor**: Code restructuring without behavior changes
- [ ] **chore**: Infrastructure, CI/CD, or tooling changes
- [ ] **BREAKING**: Breaking changes (MAJOR version bump)

## Changes Made

<!-- List the specific files/content added or modified -->

-
-
-

## Validation Checklist

<!-- ⚠️ PLACEHOLDER: Customize this checklist for your project -->

### Pre-commit Validation
- [ ] All pre-commit hooks passed locally
- [ ] No validation errors in CI/CD

### Documentation
- [ ] CHANGELOG updated with changes
- [ ] Version bump type documented (MAJOR/MINOR/PATCH or NONE)

### Testing
- [ ] Local testing completed
- [ ] All CI checks pass

## Semantic Versioning

**Proposed Version**: `vX.Y.Z`

**Justification**:
<!-- Explain why this version bump is appropriate -->
- MAJOR (X): Breaking changes? API changes?
- MINOR (Y): New features? Backward compatible additions?
- PATCH (Z): Bug fixes? Documentation updates?

## Post-Merge Actions

<!-- Any manual steps needed after merge? -->

- [ ] Create GitHub release with tag `vX.Y.Z`
- [ ] Other: _____

---

**Related Issues**: Closes #XXX (if applicable)

**Breaking Changes**: <!-- Describe any breaking changes, or write "None" -->

**Migration Guide**: <!-- If breaking, describe how to adapt, or write "N/A" -->
